module.exports = function (sequelize, DataTypes) {
  return sequelize.define('StudentProject', {
  });
};