angular.module('app')
  .controller('helpRequestCtrl', function ($scope){
    $scope.test = 'test'; 
  });