describe('teacherClassCtrl', function(){

});