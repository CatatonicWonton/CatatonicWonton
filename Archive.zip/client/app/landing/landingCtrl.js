angular.module('app')
  .controller('landingCtrl', function ($scope){
    $scope.test = 'test'; 
  });